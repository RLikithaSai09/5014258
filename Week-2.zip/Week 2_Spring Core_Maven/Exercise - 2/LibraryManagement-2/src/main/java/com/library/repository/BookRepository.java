package com.library.repository;

public class BookRepository {
    public void bookRepoContents() {
        System.out.println("Book Repository is currently empty");
    }
}
