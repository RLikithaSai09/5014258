package com.library.repository;

public class BookRepository {
    public BookRepository(){
        System.out.println("This is a book repository class");
    }
}
