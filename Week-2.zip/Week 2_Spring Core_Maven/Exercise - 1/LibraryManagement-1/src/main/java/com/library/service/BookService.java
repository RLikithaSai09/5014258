package com.library.service;

public class BookService {
    public BookService(){
        System.out.println("This is a book service class");
    }
}
